#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <vector>
//#include "user.h"
#include "navigation.h"
using namespace std;

int main()
{
    Navigation menu;
    menu.mainmenu();

    return 0;
}
